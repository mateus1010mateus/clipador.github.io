import os
import subprocess
import GPUtil

# Definindo a resolução padrão (720p) e a taxa de bits padrão (2000k)
RESOLUCAO = (720, 1280)  # Proporção 9:16 (720p)
TAXA_DE_BITS = '1500k'

def detectar_gpu():
    gpus = GPUtil.getGPUs()
    if not gpus:
        return None, None
    gpu = gpus[0]
    return gpu.name, gpu.driver

def selecionar_aceleracao(gpu_name):
    if "nvidia" in gpu_name.lower():
        return "-c:v h264_nvenc"
    elif "amd" in gpu_name.lower():
        return "-c:v h264_amf"
    elif "intel" in gpu_name.lower():
        return "-c:v h264_qsv"
    else:
        return "-c:v libx264"  # Fallback para codificação por software

def editar_video(video_entrada, prefixo_saida, gpu_selecionada=None, duracao_manual=None):
    try:
        # Verificar se o arquivo de entrada existe
        if not os.path.isfile(video_entrada):
            raise FileNotFoundError(f"O arquivo de vídeo '{video_entrada}' não foi encontrado.")
        
        # Detectar GPU e escolher o método de aceleração
        if gpu_selecionada:
            print(f"GPU selecionada manualmente: {gpu_selecionada}")
            aceleracao = selecionar_aceleracao(gpu_selecionada)
        else:
            gpu_name, driver_version = detectar_gpu()
            if gpu_name:
                print(f"GPU detectada: {gpu_name} com driver {driver_version}")
                aceleracao = selecionar_aceleracao(gpu_name)
            else:
                print("Nenhuma GPU detectada. Usando codificação por software.")
                aceleracao = selecionar_aceleracao("")

        # Criar diretório de saída se não existir
        dir_saida = os.path.abspath(prefixo_saida)
        os.makedirs(dir_saida, exist_ok=True)

        # Obter informações sobre o vídeo original
        if not duracao_manual:
            comando = f"ffprobe -v error -select_streams v:0 -show_entries stream=duration -of default=noprint_wrappers=1:nokey=1 \"{video_entrada}\""
            duracao_str = os.popen(comando).read().strip()
            
            if duracao_str == 'N/A' or not duracao_str:
                duracao_str = input("Não foi possível determinar a duração do vídeo. Digite a duração em segundos: ")
            
            duracao = float(duracao_str)
        else:
            duracao = float(duracao_manual)

        # Processar cada minuto do vídeo
        for i in range(int(duracao // 60) + 1):
            inicio = i * 60
            fim = min((i + 1) * 60, duracao)
            
            # Configurar o comando ffmpeg para editar o vídeo de 1 minuto
            arquivo_saida = os.path.join(dir_saida, f"parte{i + 1}.mp4")
            comando = (f"ffmpeg -ss {inicio} -i \"{video_entrada}\" "
                      f"-t {fim-inicio} "  # Duração do segmento
                      f"-vf \"scale={RESOLUCAO[1]}:{RESOLUCAO[1]},crop={RESOLUCAO[0]}:{RESOLUCAO[1]},pad={RESOLUCAO[0]}:{RESOLUCAO[1]}:(ow-iw)/2:(oh-ih)/2:color=blue,"
                      f"drawtext=text='video gato parte {i + 1}':fontsize=26:fontcolor=black:box=1:boxcolor=ffffff:x=(w-text_w)/2:y=50,"
                      f"eq=saturation=1.5:contrast=1.2\" "
                      f"{aceleracao} -preset fast -b:v {TAXA_DE_BITS} "
                      f"-c:a aac -strict experimental "
                      f"\"{arquivo_saida}\"")

            # Executar o comando ffmpeg
            print(f"Processando parte {i + 1} do vídeo...")
            os.system(comando)
            
            print(f"{arquivo_saida} salvo com sucesso!")

        print("Processamento concluído.")

    except Exception as e:
        print(f"Ocorreu um erro durante a edição do vídeo: {e}")

# Exemplo de uso
if __name__ == "__main__":
    video_entrada = r"C:\Users\Administrator\Documents\aula\gatosengraçados.mkv"
    prefixo_saida = r"C:\Users\Administrator\Documents\aula\video"
    
    # Solicitar GPU manualmente
    gpu_selecionada = input("Digite o nome da GPU a ser usada (ou pressione Enter para detectar automaticamente): ")

    # Solicitar duração manualmente
    duracao_manual = input("Digite a duração do vídeo em segundos (ou pressione Enter para determinar automaticamente): ")
    duracao_manual = duracao_manual.strip() or None

    editar_video(video_entrada, prefixo_saida, gpu_selecionada, duracao_manual)
